// swift-tools-version: 5.9
// The swift-tools-version declares the minimum version of Swift required to build this package.

import PackageDescription

// MARK: - Convenience
extension Target {
    var asDependency: Dependency { .target(name: name) }
    var asLibrary: Product { .library(name: name, targets: [name]) }
}

// MARK: - Configuration
let swiftSettings: [SwiftSetting] = [
    .interoperabilityMode(.Cxx),
//    .unsafeFlags(["-enable-library-evolution"]),
//    .define("ImageDataTransformationEnabled"),
]

/// only used as a testing convenience, should not be exposed or enabled in release
let includeMetadataReader: Bool = false

// MARK: - Targets
/// C++ intermediate layer replacing AudioMetadata class hierarchy from SFBAudioEngine.
let taglibBridge = Target.target(
    name: "CxxTagLibBridge",
    dependencies: [
        .product(name: "taglib", package: "CXXTagLib"),
    ],
    path: "XCFrameworkPackage/Sources/CxxTagLibBridge",
    publicHeadersPath: "include",
    cxxSettings: [
        .headerSearchPath("include/CxxTagLibBridge")
    ],
    linkerSettings: [
        .linkedFramework("CoreFoundation"),
        .linkedFramework("ImageIO"),
    ]
)
/// Swift facade
let swiftTagLib = Target.target(
    name: "SwiftTagLib",
    dependencies: [
        taglibBridge.asDependency,
    ],
    path: "XCFrameworkPackage/Sources/SwiftTagLib",
    swiftSettings: swiftSettings
)

let tests = Target.testTarget(
    name: "SwiftTagLibTests",
    dependencies: [
        swiftTagLib.asDependency,
    ],
    path: "XCFrameworkPackage/Tests/SwiftTagLibTests",
    swiftSettings: swiftSettings
)

// MARK: - Package
let package = Package(
    name: "SwiftTagLib",
    platforms: [
        .iOS(.v17),
        .macOS(.v14),
    ],
    products: [
        swiftTagLib.asLibrary,
    ],
    dependencies: [
        .package(url: "https://github.com/sbooth/CXXTagLib", from: "2.3.0"),
    ],
    targets: [
        taglibBridge,
        swiftTagLib,
        tests
    ],
    cxxLanguageStandard: .cxx20
)

// MARK: - MetadataReader Executable
if includeMetadataReader {
    package.dependencies += [
        .package(url: "https://github.com/apple/swift-argument-parser", .upToNextMajor(from: "1.5.0")),
    ]
    let metadataReader = Target.executableTarget(
        name: "MetadataReader",
        dependencies: [
            swiftTagLib.asDependency,
            .product(name: "ArgumentParser", package: "swift-argument-parser"),
        ],
        path: "XCFrameworkPackage/Sources/MetadataReader",
        swiftSettings: swiftSettings
    )
    package.targets.append(metadataReader)
    package.products.append(.executable(name: "read-metadata", targets: [metadataReader.name]))
}
