/***************************************************************************
    copyright            : (C) 2002 - 2008 by Scott Wheeler
    email                : wheeler@kde.org
 ***************************************************************************/

/***************************************************************************
 *   This library is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU Lesser General Public License version   *
 *   2.1 as published by the Free Software Foundation.                     *
 *                                                                         *
 *   This library is distributed in the hope that it will be useful, but   *
 *   WITHOUT ANY WARRANTY; without even the implied warranty of            *
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU     *
 *   Lesser General Public License for more details.                       *
 *                                                                         *
 *   You should have received a copy of the GNU Lesser General Public      *
 *   License along with this library; if not, write to the Free Software   *
 *   Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA         *
 *   02110-1301  USA                                                       *
 *                                                                         *
 *   Alternatively, this file is available under the Mozilla Public        *
 *   License Version 1.1.  You may obtain a copy of the License at         *
 *   http://www.mozilla.org/MPL/                                           *
 ***************************************************************************/

#ifndef TAGLIB_COMMENTSFRAME_H
#define TAGLIB_COMMENTSFRAME_H

#include "taglib_export.h"
#include "id3v2frame.h"

namespace TagLib {

  namespace ID3v2 {

    //! An implementation of ID3v2 comments

    /*!
     * This implements the ID3v2 comment format.  An ID3v2 comment consists of
     * a language encoding, a description and a single text field.
     */

    class TAGLIB_EXPORT CommentsFrame : public Frame
    {
      friend class FrameFactory;

    public:
      /*!
       * Construct an empty comment frame that will use the text encoding
       * \a encoding.
       */
      explicit CommentsFrame(String::Type encoding = String::Latin1);

      /*!
       * Construct a comment based on the data in \a data.
       */
      explicit CommentsFrame(const ByteVector &data);

      /*!
       * Destroys this CommentFrame instance.
       */
      ~CommentsFrame() override;

      CommentsFrame(const CommentsFrame &) = delete;
      CommentsFrame &operator=(const CommentsFrame &) = delete;

      /*!
       * Returns the text of this comment.
       *
       * \see text()
       */
      String toString() const override;

      /*!
       * Returns the language encoding as a 3 byte encoding as specified by
       * <a href="http://en.wikipedia.org/wiki/ISO_639">ISO-639-2</a>.
       *
       * \note Most taggers simply ignore this value.
       *
       * \see setLanguage()
       */
      ByteVector language() const;

      /*!
       * Returns the description of this comment.
       *
       * \note Most taggers simply ignore this value.
       *
       * \see setDescription()
       */
      String description() const;

      /*!
       * Returns the text of this comment.
       *
       * \see setText()
       */
      String text() const;

      /*!
       * Set the language using the 3 byte language code from
       * <a href="http://en.wikipedia.org/wiki/ISO_639">ISO-639-2</a> to
       * \a languageEncoding.
       *
       * \see language()
       */
      void setLanguage(const ByteVector &languageEncoding);

      /*!
       * Sets the description of the comment to \a s.
       *
       * \see description()
       */
      void setDescription(const String &s);

      /*!
       * Sets the text portion of the comment to \a s.
       *
       * \see text()
       */
      void setText(const String &s) override;

      /*!
       * Returns the text encoding that will be used in rendering this frame.
       * This defaults to the type that was either specified in the constructor
       * or read from the frame when parsed.
       *
       * \see setTextEncoding()
       * \see render()
       */
      String::Type textEncoding() const;

      /*!
       * Sets the text encoding to be used when rendering this frame to
       * \a encoding.
       *
       * \see textEncoding()
       * \see render()
       */
      void setTextEncoding(String::Type encoding);

      /*!
       * Parses this frame as PropertyMap with a single key.
       * - if description() is empty or "COMMENT", the key will be "COMMENT"
       * - if description() is not a valid PropertyMap key, the frame will be
       *   marked unsupported by an entry "COMM/<description>" in the unsupportedData()
       *   attribute of the returned map.
       * - otherwise, the key will be "COMMENT:<description>"
       * - The single value will be the frame's text().
       */
      PropertyMap asProperties() const override;

      /*!
       * Comments each have a unique description.  This searches for a comment
       * frame with the description \a d and returns a pointer to it.  If no
       * frame is found that matches the given description, null is returned.
       *
       * \see description()
       */
      static CommentsFrame *findByDescription(const Tag *tag, const String &d);

    protected:
      // Reimplementations.

      void parseFields(const ByteVector &data) override;
      ByteVector renderFields() const override;

    private:
      /*!
       * The constructor used by the FrameFactory.
       */
      CommentsFrame(const ByteVector &data, Header *h);

      class CommentsFramePrivate;
      TAGLIB_MSVC_SUPPRESS_WARNING_NEEDS_TO_HAVE_DLL_INTERFACE
      std::unique_ptr<CommentsFramePrivate> d;
    };

  }  // namespace ID3v2
}  // namespace TagLib
#endif
